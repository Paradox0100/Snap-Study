if (localStorage.getItem('user') !== null) {
  window.location.href = 'main.html';
} else {
    window.location.href = 'signup.html';
}