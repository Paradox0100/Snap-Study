document.addEventListener("deviceready", function () {
function GBI(id) {
    return document.getElementById(id);
} 

function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

function submitData() {
    let username = GBI('username').value;
    let password = GBI('password').value;
    let email = GBI('email').value;

    if (!username || !password || !email) {
        alert('Please fill in all fields');
        return;
    } else if (username.length > 15 || password.length > 15) {
        alert('Username and Password max length is 15 characters');
        return;
        
    } else if (!isValidEmail(email)) {
        alert('Please enter a valid email');
        return;
    }

    cordova.plugin.http.post(
        "https://studio.code.org/datablock_storage/AGiA3Cf2xU-jhXX_rcXslv9Ju1X8zJbYKR2Ru7LmrE0/create_record",
        { // The body as key-value pairs
            table_name: "users",
            record_json: JSON.stringify({
                username: "hi",
                password: "there",
                email: "boss"
            })
        },
        { // The headers
            "Accept": "*/*",
            "Content-Type": "application/json",
            "X-CSRF-Token": "IIJqDLaOl9vMJA3U0gFwvs9LKhmuD1kmFyE7IO2y52pbYQycjwl8IjGHZ9f7EmOoF7ilrE5r3zqK9Z3_dn_aJg",
            "X-Requested-With": "XMLHttpRequest"
        },
        function(response) {
            console.log("Success:", response.status);
            console.log("Response data:", response.data);
        },
        function(error) {
            console.error("Error:", error.status);
            console.error("Error details:", error.error);
        }
    );
    
}
}, false);